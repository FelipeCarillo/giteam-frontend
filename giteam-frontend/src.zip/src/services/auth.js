import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';
const GITHUB_AUTH_URL = 'https://github.com/login/oauth/authorize';
const GITHUB_CLIENT_ID = process.env.REACT_APP_GITHUB_CLIENT_ID || 'Ov23linOYnTKk8j7uTP9';
const GITHUB_REDIRECT_URL = process.env.REACT_APP_GITHUB_REDIRECT_URL || 'http://localhost:3000/auth/callback';

export const loginWithGitHub = () => {
    window.location.href = `${GITHUB_AUTH_URL}?client_id=${GITHUB_CLIENT_ID}&redirect_uri=${encodeURIComponent(GITHUB_REDIRECT_URL)}&scope=user,repo`;
};

export const isAuthenticated = () => {
    const token = localStorage.getItem('githubToken');
    return !!token;
};

export const getToken = () => {
    return localStorage.getItem('githubToken');
};

export const getUserInfo = async () => {
    const token = getToken();

    if (!token) {
        throw new Error('No authentication token found');
    }

    try {
        const response = await axios.get(`${API_URL}/user`, {
            headers: { Authorization: `Bearer ${token}` }
        });

        return response.data;
    } catch (error) {
        if (error.response && error.response.status === 401) {
            logout();
        }
        throw error;
    }
};

export const logout = () => {
    localStorage.removeItem('githubToken');
    window.location.href = '/';
};