import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { 
  Box, 
  CircularProgress, 
  Typography, 
  Paper, 
  Container,
  useTheme,
  useMediaQuery,
  Button,
  Fade
} from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import SmartToyOutlinedIcon from '@mui/icons-material/SmartToyOutlined';
import GitHubIcon from '@mui/icons-material/GitHub';

function AuthCallback() {
  const [isProcessing, setIsProcessing] = useState(true);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState(null);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const isDarkMode = theme.palette.mode === 'dark';

  useEffect(() => {
    const processAuth = async () => {
      try {
        // Simulate a slight delay for better UX when the response is too quick
        const minProcessingTime = new Promise(resolve => setTimeout(resolve, 1500));
        
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get('code');
        
        if (!code) {
          throw new Error('No authorization code found in URL');
        }

        const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:8000'}/auth/github/callback`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ code }),
        });

        await minProcessingTime;

        if (!response.ok) {
          throw new Error(`Authentication failed: ${response.statusText}`);
        }

        const data = await response.json();
        localStorage.setItem('githubToken', data.token);
        
        setIsSuccess(true);
        
        // Auto-redirect after success
        setTimeout(() => {
          window.location.href = '/dashboard';
        }, 1500);
        
      } catch (err) {
        console.error('Authentication error:', err);
        setError(err.message);
      } finally {
        setIsProcessing(false);
      }
    };

    processAuth();
  }, []);

  const handleReturnHome = () => {
    window.location.href = '/';
  };

  const bgColor = isDarkMode ? '#0d1117' : '#f6f8fa';
  const paperBgColor = isDarkMode ? '#161b22' : '#ffffff';
  const primaryTextColor = isDarkMode ? '#f0f6fc' : '#24292e';
  const secondaryTextColor = isDarkMode ? '#8b949e' : '#57606a';
  const borderColor = isDarkMode ? '#30363d' : 'rgba(0,0,0,0.08)';
  const primaryColor = '#2ea44f'; // GitHub green

  return (
    <Box
      sx={{
        minHeight: '100vh',
        backgroundColor: bgColor,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        p: 2
      }}
    >
      <Fade in={true} timeout={800}>
        <Container maxWidth="sm">
          <Paper
            elevation={3}
            sx={{
              borderRadius: 2,
              overflow: 'hidden',
              border: `1px solid ${borderColor}`,
              backgroundColor: paperBgColor,
            }}
          >
            {/* Header */}
            <Box 
              sx={{ 
                p: 3, 
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderBottom: `1px solid ${borderColor}`,
              }}
            >
              <SmartToyOutlinedIcon
                sx={{
                  fontSize: 32,
                  mr: 1.5,
                  color: primaryColor,
                }}
              />
              <Typography
                variant="h5"
                fontWeight="bold"
                sx={{ color: primaryTextColor }}
              >
                GiTeam
              </Typography>
            </Box>

            {/* Content */}
            <Box 
              sx={{ 
                p: 4,
                textAlign: 'center',
                minHeight: '260px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              {isProcessing && (
                <>
                  <Box 
                    sx={{ 
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mb: 3,
                      position: 'relative'
                    }}
                  >
                    <CircularProgress 
                      size={70} 
                      thickness={3}
                      sx={{ color: primaryColor }}
                    />
                    <GitHubIcon 
                      sx={{ 
                        position: 'absolute',
                        fontSize: 30,
                        color: primaryTextColor
                      }} 
                    />
                  </Box>
                  <Typography 
                    variant="h6" 
                    gutterBottom
                    sx={{ color: primaryTextColor, fontWeight: 500 }}
                  >
                    Connecting with GitHub
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ color: secondaryTextColor, maxWidth: '80%', mx: 'auto' }}
                  >
                    Please wait while we securely authenticate your GitHub account
                  </Typography>
                </>
              )}

              {isSuccess && !isProcessing && (
                <>
                  <CheckCircleOutlineIcon 
                    sx={{ 
                      fontSize: 80, 
                      color: primaryColor,
                      mb: 2
                    }} 
                  />
                  <Typography 
                    variant="h6" 
                    gutterBottom
                    sx={{ color: primaryTextColor, fontWeight: 500 }}
                  >
                    Authentication Successful!
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ color: secondaryTextColor, mb: 3 }}
                  >
                    Redirecting you to dashboard...
                  </Typography>
                  <CircularProgress 
                    size={24} 
                    thickness={5}
                    sx={{ color: secondaryTextColor, opacity: 0.5 }}
                  />
                </>
              )}

              {error && !isProcessing && (
                <>
                  <ErrorOutlineIcon 
                    sx={{ 
                      fontSize: 80,
                      color: theme.palette.error.main,
                      mb: 2
                    }} 
                  />
                  <Typography 
                    variant="h6" 
                    gutterBottom
                    sx={{ color: primaryTextColor, fontWeight: 500 }}
                  >
                    Authentication Error
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ 
                      color: secondaryTextColor, 
                      mb: 3,
                      p: 1,
                      backgroundColor: isDarkMode ? 'rgba(255,0,0,0.05)' : 'rgba(255,0,0,0.03)',
                      borderRadius: 1,
                      border: `1px solid ${isDarkMode ? 'rgba(255,0,0,0.1)' : 'rgba(255,0,0,0.08)'}`,
                    }}
                  >
                    {error}
                  </Typography>
                  <Button
                    variant="contained"
                    onClick={handleReturnHome}
                    sx={{
                      mt: 2,
                      backgroundColor: isDarkMode ? '#238636' : primaryColor,
                      '&:hover': {
                        backgroundColor: isDarkMode ? '#2ea043' : '#2c974b',
                      },
                      px: 3,
                      py: 1
                    }}
                  >
                    Return to Homepage
                  </Button>
                </>
              )}
            </Box>

            {/* Footer */}
            <Box 
              sx={{ 
                p: 2, 
                backgroundColor: isDarkMode ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.01)',
                borderTop: `1px solid ${borderColor}`,
                textAlign: 'center'
              }}
            >
              <Typography
                variant="caption"
                sx={{ color: secondaryTextColor }}
              >
                Secure authentication powered by GiTeam & GitHub OAuth
              </Typography>
            </Box>
          </Paper>
        </Container>
      </Fade>
    </Box>
  );
}

export default AuthCallback;