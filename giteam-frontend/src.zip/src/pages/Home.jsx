import React from 'react';
import {
    Box,
    Button,
    Container,
    Typography,
    Paper,
    Grid,
    useTheme,
    useMediaQuery,
    Divider
} from '@mui/material';
import GitHubIcon from '@mui/icons-material/GitHub';
import SmartToyOutlinedIcon from '@mui/icons-material/SmartToyOutlined';
import CodeIcon from '@mui/icons-material/Code';
import BugReportIcon from '@mui/icons-material/BugReport';
import AutoFixHighIcon from '@mui/icons-material/AutoFixHigh';
import { loginWithGitHub } from '../services/auth';
import { darkTheme } from '../theme';

function Home() {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('md'));

    const handleGitHubLogin = () => {
        loginWithGitHub();
    };

    return (
        <Box
            sx={{
                minHeight: '100vh',
                backgroundColor: theme.palette.mode === 'dark' ? '#0d1117' : '#f6f8fa',
                overflow: 'hidden',
            }}
        >
            <Container maxWidth="xl">
                <Grid container spacing={0} sx={{ minHeight: '100vh' }}>
                    <Grid
                        item
                        xs={12}
                        md={7}
                        sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                            px: isMobile ? 2 : 6,
                            py: 6
                        }}
                    >
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
                            <SmartToyOutlinedIcon
                                sx={{
                                    fontSize: isMobile ? 40 : 54,
                                    mr: 2,
                                    color: darkTheme.palette.primary.main,
                                }}
                            />
                            <Typography
                                variant={isMobile ? "h3" : "h2"}
                                fontWeight="bold"
                                sx={{
                                    color: theme.palette.mode === 'dark' ? '#f0f6fc' : '#24292e',
                                }}
                            >
                                GiTeam
                            </Typography>
                        </Box>

                        <Typography
                            variant={isMobile ? "h5" : "h4"}
                            gutterBottom
                            sx={{
                                fontWeight: '500',
                                mb: 3,
                                color: theme.palette.mode === 'dark' ? '#c9d1d9' : '#24292e',
                            }}
                        >
                            AI-powered collaboration for your GitHub workflow
                        </Typography>

                        <Typography
                            variant="body1"
                            sx={{
                                mb: 4,
                                fontSize: isMobile ? 16 : 18,
                                maxWidth: '600px',
                                color: theme.palette.mode === 'dark' ? '#8b949e' : '#57606a',
                            }}
                        >
                            Supercharge your team with AI agents that help analyze pull requests,
                            suggest fixes for issues, and streamline code reviews - all integrated
                            seamlessly with GitHub.
                        </Typography>

                        <Grid container spacing={4} sx={{ mb: 6 }}>
                            <Grid item xs={12} sm={4}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <CodeIcon sx={{ color: '#2ea44f', mr: 1 }} />
                                    <Typography variant="body1" fontWeight="500">
                                        Smart PR Reviews
                                    </Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <BugReportIcon sx={{ color: '#2ea44f', mr: 1 }} />
                                    <Typography variant="body1" fontWeight="500">
                                        Issue Analysis
                                    </Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <AutoFixHighIcon sx={{ color: '#2ea44f', mr: 1 }} />
                                    <Typography variant="body1" fontWeight="500">
                                        Code Suggestions
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>

                        {isMobile && (
                            <Button
                                variant="contained"
                                size="large"
                                onClick={handleGitHubLogin}
                                startIcon={<GitHubIcon />}
                                sx={{
                                    backgroundColor: '#24292e',
                                    '&:hover': {
                                        backgroundColor: '#2c333a',
                                    },
                                    py: 1.5,
                                    mb: 4
                                }}
                            >
                                Sign in with GitHub
                            </Button>
                        )}
                    </Grid>

                    <Grid
                        item
                        xs={12}
                        md={5}
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            position: 'relative',
                        }}
                    >
                        {!isMobile && (
                            <Box
                                sx={{
                                    position: 'absolute',
                                    top: 0,
                                    bottom: 0,
                                    left: 0,
                                    width: '1px',
                                    backgroundColor: theme.palette.mode === 'dark' ? '#30363d' : '#d0d7de',
                                }}
                            />
                        )}

                        <Paper
                            elevation={3}
                            sx={{
                                p: 4,
                                borderRadius: 2,
                                width: isMobile ? '100%' : '70%',
                                backgroundColor: theme.palette.mode === 'dark' ? '#161b22' : '#ffffff',
                                border: theme.palette.mode === 'dark' ? '1px solid #30363d' : 'none',
                            }}
                        >
                            <Typography
                                variant="h5"
                                align="center"
                                gutterBottom
                                sx={{
                                    fontWeight: '500',
                                    mb: 3,
                                    color: theme.palette.mode === 'dark' ? '#f0f6fc' : '#24292e',
                                }}
                            >
                                Get started with GiTeam
                            </Typography>

                            <Typography
                                variant="body2"
                                align="center"
                                sx={{
                                    mb: 4,
                                    color: theme.palette.mode === 'dark' ? '#8b949e' : '#57606a',
                                }}
                            >
                                Connect your GitHub account to start using AI-powered collaboration tools
                            </Typography>

                            <Button
                                variant="contained"
                                fullWidth
                                size="large"
                                onClick={handleGitHubLogin}
                                startIcon={<GitHubIcon />}
                                sx={{
                                    backgroundColor: '#24292e',
                                    '&:hover': {
                                        backgroundColor: '#2c333a',
                                    },
                                    py: 1.5,
                                }}
                            >
                                Sign in with GitHub
                            </Button>

                            <Box sx={{ mt: 3 }}>
                                <Divider>
                                    <Typography
                                        variant="body2"
                                        sx={{
                                            color: theme.palette.mode === 'dark' ? '#8b949e' : '#57606a',
                                            px: 1
                                        }}
                                    >
                                        Why GitHub?
                                    </Typography>
                                </Divider>
                            </Box>

                            <Typography
                                variant="body2"
                                align="center"
                                sx={{
                                    mt: 2,
                                    color: theme.palette.mode === 'dark' ? '#8b949e' : '#57606a',
                                }}
                            >
                                GiTeam needs repository access to analyze PRs and issues.
                                We only request necessary permissions to provide our services.
                            </Typography>
                        </Paper>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    );
}

export default Home;